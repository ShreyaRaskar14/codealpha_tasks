NETFLIX USER DATA - TASK 2: EXPLORATORY DATA ANALYSIS

Contents
Netflix_User_EDA.py: complete commented Python script covering steps 1-7.
netflix.csv: original supplied dataset.
EDA_Output/: eight charts, observations and conclusion in EDA_Report.txt,
plus summary tables.

Run instructions
1. Extract this ZIP into a folder.
2. Open the folder in VS Code.
3. Open Terminal and install packages:
   python -m pip install pandas matplotlib seaborn scipy
4. Run:
   python Netflix_User_EDA.py
5. Open EDA_Output to view the saved graphs and report.

Charts are saved as PNG files instead of opening in separate windows.
No personal file path needs to be edited when the CSV is beside the script.
Review the analysis before submitting. Add your exact Kaggle dataset URL,
creator and license to your submission; these were not provided.
The seven steps belong to Task 2 (EDA), not seven separate assignments.
