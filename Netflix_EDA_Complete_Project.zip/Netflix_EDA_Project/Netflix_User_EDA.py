"""
TASK 2: EXPLORATORY DATA ANALYSIS (EDA) - NETFLIX USER DATA
=======================================================================
Dataset: netflix.csv, supplied by the student (reported source: Kaggle).
Exact Kaggle dataset URL and collection method were not supplied.

This file covers all seven steps discussed for Task 2; these are not
seven separate internship assignments.

HOW TO RUN (VS Code terminal or Command Prompt)
1. Keep this Python file and netflix.csv in the same folder.
2. Install packages once:
   python -m pip install pandas matplotlib seaborn scipy
3. Run:
   python Netflix_User_EDA.py
   Optional custom input: python Netflix_User_EDA.py path/to/netflix.csv

OUTPUTS
An EDA_Output folder beside this script contains eight PNG charts,
EDA_Report.txt (questions, tables, observations, tests and conclusion),
and summary CSV tables. The original dataset is never overwritten.
Charts are saved automatically; open the PNG files to see them.

STUDY WORKFLOW
Questions -> Structure -> Quality checks -> Charts -> Hypothesis tests
          -> Issues and limitations -> Conclusion

Important: Watch_Time_Hours has no stated measurement period. It must
not be described as daily, monthly or annual watch time. Favorite_Genre
is a preference, not a record of what was actually watched.
"""

from pathlib import Path
import sys

try:
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")  # Save charts reliably without opening many windows.
    import matplotlib.pyplot as plt
    import seaborn as sns
    from scipy.stats import kruskal, spearmanr
except ImportError as error:
    raise SystemExit(
        "A required package is missing. Run this command, then try again:\n"
        "python -m pip install pandas matplotlib seaborn scipy\n"
        f"Details: {error}"
    )

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / "EDA_Output"
REPORT = []


def write(text=""):
    """Print the analysis and also collect it for the report."""
    text = str(text)
    print(text)
    REPORT.append(text)


def heading(title):
    write("\n" + "=" * 72)
    write(title)
    write("=" * 72)


def save_chart(filename, observation):
    """Save a chart with a short observation printed below the plot."""
    import textwrap
    fig = plt.gcf()
    fig.tight_layout(rect=(0, 0.19, 1, 1))
    fig.text(0.04, 0.025, textwrap.fill("Observation: " + observation, 110),
             fontsize=9, va="bottom")
    fig.savefig(OUTPUT / filename, dpi=160, bbox_inches="tight")
    plt.close(fig)
    write("\nChart: " + filename)
    write("Observation: " + observation)


def main():
    csv_path = Path(sys.argv[1]).expanduser() if len(sys.argv) > 1 else BASE / "netflix.csv"
    if not csv_path.is_file():
        raise SystemExit(
            f"Cannot find {csv_path}\nKeep netflix.csv in the same folder as "
            "this script, or provide its path after the script name."
        )
    df = pd.read_csv(csv_path)
    required = ["User_ID", "Name", "Age", "Country", "Subscription_Type",
                "Watch_Time_Hours", "Favorite_Genre", "Last_Login"]
    missing_columns = [c for c in required if c not in df.columns]
    if missing_columns:
        raise SystemExit("Required columns are missing: " + ", ".join(missing_columns))
    if df.empty:
        raise SystemExit("The CSV has no records to analyse.")
    OUTPUT.mkdir(exist_ok=True)
    sns.set_theme(style="whitegrid")
    pd.set_option("display.max_columns", None)

    heading("TASK 2: NETFLIX USER DATA - EXPLORATORY DATA ANALYSIS")
    write("Source: student-provided netflix.csv, reported as downloaded from Kaggle.")
    write("Dataset URL, collection method and viewing period require confirmation.")
    write("Input file: " + csv_path.name)
    write("Objective: explore user profiles, preferences and viewing behaviour; "
          "test selected relationships and identify data issues.")

    # STEP 1: Decide what to investigate BEFORE analysing the results.
    heading("STEP 1: MEANINGFUL QUESTIONS")
    questions = [
        "Which subscription plan has the most users?",
        "Which favourite genre has the most users?",
        "How is watch time distributed?",
        "Does watch time differ between subscription plans?",
        "Is age related to watch time?",
        "Which country has the highest average watch time?",
        "Are there missing values, duplicate IDs, invalid dates or outliers?"
    ]
    for number, question in enumerate(questions, 1):
        write(f"{number}. {question}")
    write("Hypothesis A (H0): watch-time distributions are the same across plans.")
    write("Hypothesis A (H1): at least one plan's distribution differs.")
    write("Hypothesis B (H0): population Spearman correlation of age and watch time is zero.")
    write("Hypothesis B (H1): that correlation is not zero (two-sided test).")

    # STEP 2: Understand the rows, columns, meanings and data types.
    heading("STEP 2: DATA STRUCTURE AND DESCRIPTIVE STATISTICS")
    write(f"Rows: {len(df):,}; columns: {len(df.columns)}")
    write("\nFirst five records:\n" + df.head().to_string(index=False))
    write("\nOriginal data types:\n" + df.dtypes.to_string())
    dictionary = pd.DataFrame({
        "Column": required,
        "Meaning": ["User identifier", "User name", "Age in years", "Country",
                    "Subscription plan", "Viewing hours; period unspecified",
                    "Preferred genre", "Most recent recorded login"],
        "Analysis type": ["Identifier", "Text", "Numerical", "Categorical",
                          "Categorical", "Numerical", "Categorical", "Date"]
    })
    write("\nData dictionary:\n" + dictionary.to_string(index=False))
    dictionary.to_csv(OUTPUT / "data_dictionary.csv", index=False)
    write("User_ID is an identifier: its mean and correlation are not meaningful.")
    write("Names are not needed for behavioural analysis or chart labels.")
    original_missing = df.isna().sum()
    original_duplicates = int(df.duplicated().sum())
    duplicate_ids = int(df["User_ID"].dropna().duplicated().sum())
    raw_dates = df["Last_Login"].copy()
    df["Last_Login"] = pd.to_datetime(raw_dates, format="%Y-%m-%d", errors="coerce")
    invalid_dates = int((raw_dates.notna() & df["Last_Login"].isna()).sum())
    numeric_failures = {}
    for column in ["Age", "Watch_Time_Hours"]:
        original = df[column].copy()
        df[column] = pd.to_numeric(original, errors="coerce")
        numeric_failures[column] = int((original.notna() & df[column].isna()).sum())
    stats = df[["Age", "Watch_Time_Hours"]].describe().round(2)
    write("\nNumerical summary:\n" + stats.to_string())
    stats.to_csv(OUTPUT / "numerical_summary.csv")
    write("\nDate type after conversion: " + str(df["Last_Login"].dtype))
    write(f"Recorded last-login range: {df['Last_Login'].min()} to {df['Last_Login'].max()}")

    # STEP 3: Diagnose issues; do not invent problems or delete valid data.
    heading("STEP 3: DATA QUALITY CHECKS")
    write("Original missing values:\n" + original_missing.to_string())
    write(f"Duplicate rows: {original_duplicates}")
    write(f"Duplicate non-missing user IDs: {duplicate_ids}")
    write(f"Invalid non-missing dates: {invalid_dates}")
    write("Non-numeric values converted to missing: " + str(numeric_failures))
    negative_hours = int((df["Watch_Time_Hours"] < 0).sum())
    invalid_ages = int((df["Age"] <= 0).sum())
    write(f"Negative viewing hours: {negative_hours}")
    write(f"Zero or negative ages: {invalid_ages}")
    write("Age <= 0 is only a basic validity check; a valid age range needs source documentation.")
    for column in ["Country", "Subscription_Type", "Favorite_Genre"]:
        write(f"\n{column} categories: {list(df[column].dropna().unique())}")
        spacing = int((df[column].dropna() != df[column].dropna().str.strip()).sum())
        write(f"Values with leading/trailing spaces: {spacing}")
    write("Dates are parsed; no records are deleted or missing values guessed.")
    write("Each comparison uses records with the needed values; sample sizes are shown.")

    # STEP 4: Eight visualisations, with observations derived from the CSV.
    heading("STEP 4: VISUAL ANALYSIS AND OBSERVATIONS")
    subscriptions = df["Subscription_Type"].value_counts()
    plt.figure(figsize=(10, 6))
    ax = sns.countplot(data=df, x="Subscription_Type", order=subscriptions.index,
                       color="teal")
    for container in ax.containers:
        ax.bar_label(container, padding=3)
    plt.title("Number of Users by Subscription")
    plt.xlabel("Subscription Plan")
    plt.ylabel("Number of Users")
    obs = "; ".join(f"{plan}: {count:,} users" for plan, count in subscriptions.items())
    save_chart("01_subscription_users.png", obs + ". The counts show plan popularity in this dataset only.")
    write(subscriptions.to_string())

    genres = df["Favorite_Genre"].value_counts()
    plt.figure(figsize=(10, 6))
    ax = genres.plot(kind="bar", color="coral")
    for container in ax.containers:
        ax.bar_label(container, padding=3, fontsize=8)
    plt.title("Users by Favourite Genre")
    plt.xlabel("Favourite Genre")
    plt.ylabel("Number of Users")
    plt.xticks(rotation=35)
    save_chart("02_favourite_genres.png",
               f"{genres.idxmax()} leads with {genres.max():,} users; "
               f"{genres.idxmin()} has the fewest with {genres.min():,}. "
               "This measures stated preferences, not viewing hours by genre.")

    hours = df["Watch_Time_Hours"].dropna()
    plt.figure(figsize=(10, 6))
    sns.histplot(hours, bins=30, color="steelblue")
    plt.title("Distribution of Recorded Watch Time")
    plt.xlabel("Watch Time (Hours; Period Unspecified)")
    plt.ylabel("Number of Users")
    save_chart("03_watch_time_distribution.png",
               f"Hours range from {hours.min():.2f} to {hours.max():.2f}; "
               f"mean = {hours.mean():.2f}, median = {hours.median():.2f}, "
               f"sample skewness = {hours.skew():.3f}. "
               "A near-zero skewness suggests little asymmetry, not a normal distribution.")

    plan_summary = df.groupby("Subscription_Type")["Watch_Time_Hours"].agg(
        ["count", "mean", "median", "std"]).round(2)
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=df, x="Subscription_Type", y="Watch_Time_Hours", color="lightblue")
    plt.title("Watch Time by Subscription")
    plt.xlabel("Subscription Plan")
    plt.ylabel("Watch Time (Hours; Period Unspecified)")
    plan_obs = "; ".join(f"{plan} mean: {row['mean']:.2f} hours"
                         for plan, row in plan_summary.iterrows())
    save_chart("04_subscription_watch_time.png", plan_obs +
               ". Compare medians and spreads as well as means; the hypothesis test follows.")
    write("\nSubscription summary:\n" + plan_summary.to_string())
    plan_summary.to_csv(OUTPUT / "subscription_summary.csv")

    pairs = df[["Age", "Watch_Time_Hours"]].dropna()
    sample = pairs.sample(n=min(200, len(pairs)), random_state=42)
    rho, age_p = spearmanr(pairs["Age"], pairs["Watch_Time_Hours"])
    plt.figure(figsize=(11, 6))
    plt.scatter(sample["Age"], sample["Watch_Time_Hours"],
                color="teal", s=25, alpha=0.6)
    plt.title(f"Age vs Watch Time (Random Sample of {len(sample)} Users)")
    plt.xlabel("Age (Years)")
    plt.ylabel("Watch Time (Hours; Period Unspecified)")
    plt.grid(alpha=0.2)
    save_chart("05_age_scatter_sample.png",
               f"Only {len(sample)} users are plotted to reduce overlapping points. "
               f"The full-data Spearman correlation is {rho:.4f} (n={len(pairs):,}). "
               "A correlation near zero indicates little monotonic association.")

    countries = df.groupby("Country")["Watch_Time_Hours"].agg(
        ["count", "mean", "median"])
    country_means = countries["mean"].sort_values()
    plt.figure(figsize=(10, 7))
    ax = country_means.plot(kind="barh", color="teal")
    for container in ax.containers:
        ax.bar_label(container, fmt="%.2f", padding=3, fontsize=8)
    plt.xlim(0, country_means.max() * 1.18)
    plt.title("Average Watch Time by Country")
    plt.xlabel("Average Watch Time (Hours; Period Unspecified)")
    plt.ylabel("Country")
    save_chart("06_country_average_watch_time.png",
               f"{country_means.idxmax()} has the highest mean ({country_means.max():.2f} hours); "
               f"{country_means.idxmin()} has the lowest ({country_means.min():.2f} hours). "
               f"The gap is {country_means.max() - country_means.min():.2f} hours. "
               "This descriptive comparison does not establish a country effect.")
    write("\nCountry summary:\n" + countries.round(2).to_string())
    countries.round(2).to_csv(OUTPUT / "country_summary.csv")

    plt.figure(figsize=(10, 6))
    sns.histplot(data=df, x="Age", bins=15, color="mediumpurple")
    plt.title("Distribution of User Ages")
    plt.xlabel("Age (Years)")
    plt.ylabel("Number of Users")
    save_chart("07_age_distribution.png",
               f"Recorded ages range from {df['Age'].min():.0f} to {df['Age'].max():.0f} years. "
               f"Mean age is {df['Age'].mean():.2f} years and median age is "
               f"{df['Age'].median():.0f} years. These figures describe this sample only.")

    q1, q3 = hours.quantile([0.25, 0.75])
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    outliers = df[(df["Watch_Time_Hours"] < lower) |
                  (df["Watch_Time_Hours"] > upper)]
    plt.figure(figsize=(10, 5))
    sns.boxplot(x=hours, color="gold")
    plt.title("Watch-Time Outlier Check (1.5 x IQR Rule)")
    plt.xlabel("Watch Time (Hours; Period Unspecified)")
    save_chart("08_watch_time_outliers.png",
               f"The IQR rule flags {len(outliers)} records. "
               f"Lower fence: {lower:.2f}; upper fence: {upper:.2f} hours. "
               "Outlier flags are screening results, not proof of errors.")

    # STEP 5: Tests use the FULL available dataset, not the chart sample.
    heading("STEP 5: HYPOTHESIS TESTS AND ASSUMPTIONS")
    write("Significance level: alpha = 0.05 for each exploratory test.")
    write("P-values do not measure effect size, prove equality or establish causation.")
    write("Two exploratory tests are reported without a multiple-testing correction.")
    write("\nTEST A: Kruskal-Wallis test across subscription plans")
    write("H0: watch-time distributions are the same across subscription plans.")
    write("H1: at least one plan's distribution differs.")
    groups = [g["Watch_Time_Hours"].dropna() for _, g in df.groupby("Subscription_Type")]
    if len(groups) < 2 or any(len(g) < 5 for g in groups):
        raise SystemExit("Kruskal-Wallis test needs at least two groups with sufficient observations.")
    h_stat, plan_p = kruskal(*groups)
    write("Valid group sizes: " + str({name: int(g["Watch_Time_Hours"].notna().sum())
                                        for name, g in df.groupby("Subscription_Type")}))
    write(f"H statistic: {h_stat:.4f}; p-value: {plan_p:.6f}")
    plan_result = ("Reject H0: evidence of a difference between groups."
                   if plan_p < 0.05 else
                   "Fail to reject H0: insufficient evidence of a difference between groups.")
    write(plan_result)
    mean_gap = plan_summary["mean"].max() - plan_summary["mean"].min()
    write(f"Descriptive size of mean gap (largest minus smallest): {mean_gap:.2f} hours.")
    write("Why this test: it compares ranked numerical values across independent groups "
          "without requiring normally distributed watch time.")
    write("Assumptions: independent users, one record per user and comparable measurements. "
          "Unique IDs support one row per ID but cannot establish independence. "
          "A median-only interpretation also needs similarly shaped group distributions; "
          "inspect the boxplots. Sampling and independence require source documentation.")

    write("\nTEST B: Spearman correlation of age and watch time")
    write("H0: population Spearman correlation is zero.")
    write("H1: population Spearman correlation is nonzero (two-sided).")
    write(f"Valid paired records: {len(pairs):,}")
    write(f"Spearman rho: {rho:.6f}; p-value: {age_p:.6f}")
    age_result = ("Reject H0: evidence of a monotonic association."
                  if age_p < 0.05 else
                  "Fail to reject H0: insufficient evidence of a monotonic association.")
    write(age_result)
    write("Why this test: it measures an increasing or decreasing rank relationship "
          "without requiring normality. It assumes independent paired observations. "
          "A near-zero result does not rule out every possible nonlinear relationship.")

    # STEP 6: Separate measurable issues from limitations of the source.
    heading("STEP 6: ANOMALIES, DATA ISSUES AND NEXT STEPS")
    write(f"IQR = Q3 - Q1 = {q3:.2f} - {q1:.2f} = {iqr:.2f}")
    write(f"Outlier fences: {lower:.2f} and {upper:.2f}; flagged rows: {len(outliers)}")
    write(f"Original missing cells: {int(original_missing.sum())}; duplicate rows: "
          f"{original_duplicates}; duplicate user IDs: {duplicate_ids}.")
    write(f"Invalid dates: {invalid_dates}; negative hours: {negative_hours}; "
          f"zero/negative ages: {invalid_ages}.")
    write("1. Confirm the exact Kaggle URL, creator, license and collection method.")
    write("2. Clarify whether the dataset is synthetic or represents real users. "
          "Balanced categories alone do not prove synthetic generation.")
    write("3. Confirm the viewing-hours measurement period before judging high values.")
    write("4. Last_Login is one date per user, not a login history. "
          "Do not infer monthly activity trends, churn or login frequency from it.")
    write("5. Confirm a dataset reference date before labelling any date as future or "
          "calculating inactivity. Do not assume today's date is the collection date.")
    write("6. No missing values or IQR outliers does not mean the dataset is error-free.")
    write("7. Country means and observed plan differences are descriptive; the data "
          "does not establish causation or represent all Netflix users.")
    write("8. Keep names and IDs out of public charts; share aggregate findings.")
    write("9. Investigate flagged records before removing or changing them. "
          "No automatic cleaning or outlier deletion was performed here.")

    # STEP 7: Final findings, calculated rather than hard-coded.
    heading("STEP 7: FINAL CONCLUSION")
    write(f"I explored {len(df):,} records and {len(df.columns)} variables to understand "
          "user characteristics, subscriptions and viewing behaviour.")
    write(f"{subscriptions.idxmax()} had the most users ({subscriptions.max():,}), "
          f"and {genres.idxmax()} was the most common favourite genre ({genres.max():,}).")
    write(f"Average recorded watch time was {hours.mean():.2f} hours, with no stated period.")
    write(f"Country averages ranged from {country_means.min():.2f} to "
          f"{country_means.max():.2f} hours.")
    write(f"For subscription plans, p = {plan_p:.4f}. {plan_result}")
    write(f"For age and watch time, rho = {rho:.4f} and p = {age_p:.4f}. {age_result}")
    write(f"Quality checks found {int(original_missing.sum())} original missing cells, "
          f"{original_duplicates} duplicate rows and {len(outliers)} IQR watch-time outliers.")
    write("Before making business recommendations, I would verify the dataset source, "
          "sampling method and watch-time period. These findings describe this dataset "
          "and should not automatically be generalised to Netflix's actual user base.")
    write("\nSubmission checklist: Python script, original CSV, generated PNG charts "
          "and EDA_Report.txt. Review and understand each section before submission.")
    (OUTPUT / "EDA_Report.txt").write_text("\n".join(REPORT), encoding="utf-8")
    print("\nCompleted. Charts, summary tables and report saved in:", OUTPUT)


if __name__ == "__main__":
    main()
